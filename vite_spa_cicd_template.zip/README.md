# Vite + Refine.js SPA CI/CD Template (S3 + CloudFront)

このテンプレートは、**CodeCommit → CodeBuild → CodePipeline → S3/CloudFront** の流れで  
Vite + Refine.js 製フロントエンドを自動デプロイする最小構成のサンプルです。

## 構成ファイル

| ファイル | 説明 |
|----------|------|
| `cloudformation-pipeline.yml` | パラメータ化された CodePipeline / CodeBuild / IAM ロール定義 |
| `buildspec.yml` | ビルド & 品質ゲート (`eslint`/`tsc`/`unit test`) と `vite build` |
| `buildspec-invalidate.yml` | S3 へ sync 後、CloudFront キャッシュを無効化 |
| `README.md` | 使い方ガイド (本ファイル) |

## 使用手順 (概要)

1. **前提**  
   - S3 バケット (静的サイト用) と CloudFront ディストリビューションを既に作成済み  
   - CodeCommit リポジトリにソースコードを push 済み
2. **CloudFormation デプロイ**  
   ```bash
   aws cloudformation deploy      --stack-name vite-spa-pipeline      --template-file cloudformation-pipeline.yml      --parameter-overrides        RepoName=vite-refine-spa        BranchName=main        ArtifactBucketName=my-artifact-bucket        WebsiteBucketName=web-prod-myapp        CloudFrontDistributionId=E******      --capabilities CAPABILITY_NAMED_IAM
   ```
3. **コミット & プッシュ**  
   ```bash
   git push origin main
   ```
   → CodePipeline が自動実行され、数分で CloudFront へ反映されます。

## NPM スクリプト例

`package.json` に以下がある想定です。

```json
{
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "eslint 'src/**/*.{ts,tsx}'",
    "typecheck": "tsc --noEmit",
    "test:ci": "vitest run --coverage"
  }
}
```

## 注意

- テンプレートでは簡易的に **AdministratorAccess** ポリシーを付与しています。  
  本番では最小権限の IAM ポリシーに置き換えてください。
- `aws cloudfront create-invalidation` は料金が発生します。  
  デプロイ頻度に応じて、ファイル名にハッシュを付け `index.html` のみ無効化する方法も検討ください。
