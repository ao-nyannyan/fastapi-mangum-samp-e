async def test_user(client):
    res = await client.post("/users/", json={"name": "Test", "email": "t@example.com"})
    assert res.status_code == 201
    uid = res.json()["id"]
    res = await client.get(f"/users/{uid}")
    assert res.status_code == 200
