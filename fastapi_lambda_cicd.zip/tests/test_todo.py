async def test_todo(client):
    user = await client.post("/users/", json={"name": "u", "email": "u@ex.com"})
    uid = user.json()["id"]
    res = await client.post("/todos/", json={"title": "x", "owner_id": uid})
    assert res.status_code == 201
    tid = res.json()["id"]
    res = await client.get(f"/todos/{tid}")
    assert res.json()["title"] == "x"
