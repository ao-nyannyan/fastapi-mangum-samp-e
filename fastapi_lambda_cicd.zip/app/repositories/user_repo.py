from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.models.user import User
from app.schemas.user import UserCreate

class UserRepository:
    async def create(self, db: AsyncSession, user_in: UserCreate):
        user = User(**user_in.dict())
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    async def list(self, db: AsyncSession):
        res = await db.execute(select(User))
        return res.scalars().all()

    async def get(self, db: AsyncSession, user_id: int):
        return await db.get(User, user_id)

    async def delete(self, db: AsyncSession, user_id: int):
        u = await self.get(db, user_id)
        if u:
            await db.delete(u)
            await db.commit()
