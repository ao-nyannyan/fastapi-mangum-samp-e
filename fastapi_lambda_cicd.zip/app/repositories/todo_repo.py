from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.models.todo import Todo
from app.schemas.todo import TodoCreate

class TodoRepository:
    async def create(self, db: AsyncSession, todo_in: TodoCreate):
        todo = Todo(**todo_in.dict())
        db.add(todo)
        await db.commit()
        await db.refresh(todo)
        return todo

    async def list(self, db: AsyncSession):
        res = await db.execute(select(Todo))
        return res.scalars().all()

    async def get(self, db: AsyncSession, todo_id: int):
        return await db.get(Todo, todo_id)

    async def delete(self, db: AsyncSession, todo_id: int):
        t = await self.get(db, todo_id)
        if t:
            await db.delete(t)
            await db.commit()
