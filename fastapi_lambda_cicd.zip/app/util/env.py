import os, json
from functools import lru_cache
from typing import Optional
from pydantic import BaseSettings
from dotenv import load_dotenv

load_dotenv(".env", override=False)

class _Settings(BaseSettings):
    database_url: Optional[str] = None
    log_level: str = "INFO"
    use_aws_param: bool = False
    aws_param_path: str = "/myapp/dev/"

    class Config:
        env_file = ".env"

@lru_cache
def settings() -> _Settings:
    s = _Settings()
    if s.use_aws_param:
        import boto3
        ssm = boto3.client("ssm")
        sec = boto3.client("secretsmanager")

        def _get(name):
            try:
                rsp = ssm.get_parameter(Name=f"{s.aws_param_path}{name}", WithDecryption=True)
                return rsp["Parameter"]["Value"]
            except ssm.exceptions.ParameterNotFound:
                return None

        for field in s.__fields__:
            val = _get(field)
            if val is not None:
                setattr(s, field, val)
        if not s.database_url:
            try:
                raw = sec.get_secret_value(SecretId="aurora-cred")["SecretString"]
                cred = json.loads(raw)
                s.database_url = f"mysql+aiomysql://{cred['username']}:{cred['password']}@{cred['host']}:{cred['port']}/{cred['dbname']}"
            except sec.exceptions.ResourceNotFoundException:
                pass
    return s
