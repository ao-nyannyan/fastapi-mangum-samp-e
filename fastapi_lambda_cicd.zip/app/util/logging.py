import json, logging, sys, time
from app.util.env import settings

class JsonFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "ts": int(time.time() * 1000),
            "lvl": record.levelname,
            "msg": record.getMessage(),
            "logger": record.name,
        })

def init_logger():
    level = settings().log_level.upper()
    root = logging.getLogger()
    root.setLevel(level)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter() if settings().use_aws_param else logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))
    root.handlers = [handler]

init_logger()
