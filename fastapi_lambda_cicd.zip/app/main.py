from fastapi import FastAPI
from app.routers import user_router, todo_router
from app.middleware.errors import ExceptionMiddleware
from app.util import logging as _  # noqa

app = FastAPI(title="Lambda FastAPI Example")
app.add_middleware(ExceptionMiddleware)

app.include_router(user_router.router, prefix="/users", tags=["Users"])
app.include_router(todo_router.router, prefix="/todos", tags=["Todos"])

@app.get("/")
async def read_root():
    return {"status": "ok"}
