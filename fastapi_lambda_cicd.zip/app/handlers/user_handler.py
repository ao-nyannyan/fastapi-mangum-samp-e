from fastapi import FastAPI
from mangum import Mangum
from app.routers.user_router import router as user_router
from app.middleware.errors import ExceptionMiddleware
from app.util import logging as _  # noqa

app = FastAPI(title="User Lambda")
app.add_middleware(ExceptionMiddleware)
app.include_router(user_router, prefix="/users")
handler = Mangum(app)
