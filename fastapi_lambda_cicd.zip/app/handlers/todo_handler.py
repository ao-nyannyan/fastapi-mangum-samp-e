from fastapi import FastAPI
from mangum import Mangum
from app.routers.todo_router import router as todo_router
from app.middleware.errors import ExceptionMiddleware
from app.util import logging as _  # noqa

app = FastAPI(title="Todo Lambda")
app.add_middleware(ExceptionMiddleware)
app.include_router(todo_router, prefix="/todos")
handler = Mangum(app)
