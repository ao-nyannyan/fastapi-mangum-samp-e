from app.repositories.user_repo import UserRepository

class UserService:
    def __init__(self):
        self.repo = UserRepository()

    async def create_user(self, db, user_in):
        return await self.repo.create(db, user_in)

    async def list_users(self, db):
        return await self.repo.list(db)

    async def get_user(self, db, user_id):
        return await self.repo.get(db, user_id)

    async def delete_user(self, db, user_id):
        await self.repo.delete(db, user_id)
