from app.repositories.todo_repo import TodoRepository

class TodoService:
    def __init__(self):
        self.repo = TodoRepository()

    async def create_todo(self, db, todo_in):
        return await self.repo.create(db, todo_in)

    async def list_todos(self, db):
        return await self.repo.list(db)

    async def get_todo(self, db, todo_id):
        return await self.repo.get(db, todo_id)

    async def delete_todo(self, db, todo_id):
        await self.repo.delete(db, todo_id)
