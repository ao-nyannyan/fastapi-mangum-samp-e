# FastAPI × Mangum × SQLAlchemy × Alembic Serverless Sample

* FastAPI + Mangum handlers (Users & Todos)
* Async SQLAlchemy → Aurora MySQL (via RDS Proxy)
* Alembic migrations **＋初期シード** 自動適用 on Docker startup
* VS Code dev‑container‑like settings
* JWT Auth ready (Cognito User Pool / HTTP API)
* CI sample (GitHub Actions)

```
docker compose up --build
# http://localhost:8000/docs
```
