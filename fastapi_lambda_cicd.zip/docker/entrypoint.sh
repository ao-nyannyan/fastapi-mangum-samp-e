#!/usr/bin/env bash
set -e

echo "Waiting for db at $DATABASE_URL ..."
python - <<'PY'
import os, time, sqlalchemy as sa, sys
url = os.getenv("DATABASE_URL")
engine = sa.create_engine(url, pool_pre_ping=True)
for _ in range(30):
    try:
        with engine.connect() as c: c.execute(sa.text("SELECT 1"))
        sys.exit(0)
    except Exception:
        time.sleep(1)
print("DB never came up", file=sys.stderr); sys.exit(1)
PY

alembic upgrade head
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload --reload-dir app -m debugpy --listen 0.0.0.0:5678
