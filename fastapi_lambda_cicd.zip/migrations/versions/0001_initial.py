"""initial schema and seed"""

from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(length=64), nullable=False),
        sa.Column("email", sa.String(length=128), unique=True, nullable=False),
    )
    op.create_table(
        "todos",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("title", sa.String(length=128), nullable=False),
        sa.Column("owner_id", sa.Integer, sa.ForeignKey("users.id"), nullable=False),
    )
    # seed
    users = sa.table(
        "users",
        sa.column("id", sa.Integer),
        sa.column("name", sa.String),
        sa.column("email", sa.String),
    )
    op.bulk_insert(
        users,
        [
            {"id": 1, "name": "Alice", "email": "alice@example.com"},
            {"id": 2, "name": "Bob", "email": "bob@example.com"},
        ],
    )

    todos = sa.table(
        "todos",
        sa.column("title", sa.String),
        sa.column("owner_id", sa.Integer),
    )
    op.bulk_insert(
        todos,
        [
            {"title": "Buy milk", "owner_id": 1},
            {"title": "Write docs", "owner_id": 2},
        ],
    )

def downgrade() -> None:
    op.drop_table("todos")
    op.drop_table("users")
